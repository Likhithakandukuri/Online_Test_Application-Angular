import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user.model';
import { UserService } from '../user.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm:FormGroup;
  submitted:boolean=false;
  user:User= new User();
  constructor(private builder:FormBuilder, private service:UserService, private router:Router,
  private http:HttpClient) { }

  ngOnInit(): void {
    this.registerForm= this.builder.group({
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',Validators.required],
      password:['',Validators.required]
    })
  }

  get form(){
    return this.registerForm.controls;
  }

  onSubmit(){

    this.http.post<any>("http://localhost:3000/users",this.registerForm.value)
    .subscribe(res=>{
    alert("Signup Successsful")
    this.router.navigate(['login']);
    },err=>{
      alert("Something went wrong")
    })
    // this.submitted=true;
    // if(this.registerForm.invalid)
    //   return;
    // else{
    //     this.service.addUser(this.user).subscribe(x=>console.log(x))
    //     alert("User added successfully")
    //     this.router.navigate(['list'])
    // }
  }
}

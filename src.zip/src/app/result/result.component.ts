import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../question.service';
// import { ResultService } from '../result.service';
// import { QuizComponent } from './quiz/quiz.component';


@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit { 
  correctAnswer:any = '';

  // public resultList : any = [];
  // public currentAnswer : number = 0;
  totalpoints: number = 0;
  resultcorrectAnswer:number;
  resultincorrectAnswer: number;
  resultList : any = [];
  isQuizCompleted: boolean = true;
debugger
  imgurl:string="./assets/images/congrats.jpg";
  constructor(public questionService : QuestionService) { }


  ngOnInit() { 
    this.resultList = this.questionService.questionList;
    this.resultcorrectAnswer = this.questionService.correctAnswer;
    this.resultincorrectAnswer = this.questionService.incorrectAnswer;
    this.totalpoints=this.questionService.points;
   }

  

}

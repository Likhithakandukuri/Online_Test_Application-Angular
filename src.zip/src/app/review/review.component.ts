import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../question.service';
import { Answer } from '../Answer.model';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

 answer:Answer = new Answer();
 public ansList : any = [];
 public id:any;
 
  constructor(private questionService : QuestionService) { }

  ngOnInit(): void {
     this.getAllAnswers();
      this.questionService.deleteAnswer(this.id);
  }
  getAllAnswers(){
    debugger
      this.questionService.getAnswers()
      .subscribe((res:any[])=>{
        this.ansList=res;
      console.log(this.ansList) 
      })

  }

}

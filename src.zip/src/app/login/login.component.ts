import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user.model';
import { UserService } from '../user.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

   loginForm:FormGroup;
   submitted:boolean=false;
  user:User= new User();
  constructor(private builder:FormBuilder, private service:UserService, private router:Router,
  private http:HttpClient) { }

  ngOnInit(): void {
    this.loginForm= this.builder.group({
      email:['',Validators.required],
      password:['',Validators.required]
    })
  }

  get form(){
    return this.loginForm.controls;
  }

   login(){

     this.http.get<any>("http://localhost:3000/users")
     .subscribe(res=>{
       const user = res.find((a:any)=>{
         return a.email === this.loginForm.value.email && a.password === this.loginForm.value.password
     });
     if(user){
     alert("Login Success");
     this.loginForm.reset();
     this.router.navigate(['dashboard']);
     }
     else{
     alert("User Not Found");
     this.router.navigate(['signup']);
     }
    // this.submitted=true;
    // if(this.loginForm.invalid)
    //   return;
    // else{
    //     this.service.addUser(this.user).subscribe(x=>console.log(x))
    //     alert("Login Successful")
    //     this.router.navigate(['list'])
    })
  }

}

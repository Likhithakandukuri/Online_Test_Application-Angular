export class Answer{
    // id:number;
    answer:string;
}
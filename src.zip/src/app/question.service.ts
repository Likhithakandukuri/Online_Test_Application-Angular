import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

  // sendMessage=new Subject();
  constructor(private http:HttpClient) { }
  correctAnswer:number = 0;
  incorrectAnswer:number = 0;
  points: number=0;
  questionList : any = [];
  getQuestions(){
    return this.http.get<any>("http://localhost:5000/questions"); 
  }

   SendAnswer(ans){
    return this.http.post("http://localhost:8000/answers",ans);
  }
  getAnswers(){
    return this.http.get<any>("http://localhost:8000/answers");
  }
  //  DeleteAnswers(){
  //   return this.http.delete<any>("http://localhost:8000/answers");
  // }
  deleteAnswer(id:any) {

    return this.http.delete("http://localhost:8000/answers"+ "/" + id);

  }
  
}

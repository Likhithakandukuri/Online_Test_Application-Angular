import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../question.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {


  public questionList : any = [];
  public currentQuestion:number = 0;
  public points: number=0;
  correctAnswer:number = 0;
  incorrectAnswer:number = 0;
  isQuizCompleted: boolean = false;
  public id:number;

  // messageFromQuiz="Hello I am from Quiz";

  constructor(private questionService : QuestionService, private router:Router, private http:HttpClient) { }

  ngOnInit(): void {
    this.getAllQuestions();
    this.questionService.deleteAnswer(this.id);
  }
 
  getAllQuestions(){
      this.questionService.getQuestions()
      .subscribe(res=>{
        this.questionList=res;
      })
  }
  
 
  nextQuestion(){
     this.currentQuestion++;
  }
  previousQuestion(){
     this.currentQuestion--;
  }
  answer(currentQno:number,option:any){

    this.questionService.SendAnswer(option).subscribe(res=>{console.log(res)
    this.questionService.getAnswers().subscribe(res=>{console.log(res)});});

    if(currentQno === this.questionService.questionList.length){
      this.isQuizCompleted = true;
    }
    if(option.correct){
      this.questionService.points+=10;
      this.questionService.correctAnswer++;
      this.currentQuestion++;
    }else{
      this.questionService.points-=5;
      this.currentQuestion++;
      this.questionService.incorrectAnswer++; 
    }
    // this.questionService.communicateCorrectAnswer(this.correctAnswer);

  }
  goToDashboard(){
     this.router.navigate(['dashboard']);
   }

}
